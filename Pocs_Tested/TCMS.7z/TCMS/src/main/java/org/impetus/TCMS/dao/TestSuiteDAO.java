/**
 * 
 */
package org.impetus.TCMS.dao;

import java.util.List;

import org.impetus.TCMS.common.db.GenericDAO;
import org.impetus.TCMS.model.Producttestsuite;
import org.impetus.TCMS.vo.TestSuiteVO;

/**
 * @author kratika.gupta
 *
 */
public interface TestSuiteDAO extends GenericDAO{

	//public String addNew(Producttestsuite prodtestsuite) throws Exception;
	public List<TestSuiteVO> gettSuiteList(Integer clientId, Integer productId) throws Exception;
	public Producttestsuite getTestSuiteFromId(Integer Id) throws Exception;
}
