package org.impetus.TCMS.vo;

public class ProductVO {

	short productid;	
	String name;
		
	public ProductVO(short productid, String name) {
		super();
		this.productid = productid;
		this.name = name;
	}
	/**
	 * @return the productid
	 */
	public short getProductid() {
		return productid;
	}
	/**
	 * @param productid the productid to set
	 */
	public void setProductid(short productid) {
		this.productid = productid;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
}
