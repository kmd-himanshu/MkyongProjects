package org.impetus.TCMS.bo;

import java.util.List;

import org.impetus.TCMS.vo.ProductVO;

public interface ProductBo {

	/**
	 * 
	 */
	public List<ProductVO> getProductList(Integer clientId) throws Exception; 	
			
}
