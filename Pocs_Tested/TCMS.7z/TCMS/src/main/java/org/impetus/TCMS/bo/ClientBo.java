/*
 * 
 */
package org.impetus.TCMS.bo;

public interface ClientBo {

}
