package org.impetus.TCMS.dao;

import java.util.List;

import org.impetus.TCMS.common.db.GenericDAO;
import org.impetus.TCMS.vo.ProductVO;

public interface ProductDAO extends GenericDAO {
	
	public List<ProductVO> getProductList(Integer clientId) throws Exception;
}
