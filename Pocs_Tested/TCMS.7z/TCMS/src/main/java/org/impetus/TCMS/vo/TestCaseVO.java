/**
 * 
 */
package org.impetus.TCMS.vo;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author kratika.gupta
 *
 */
@XmlRootElement
public class TestCaseVO {
	
	String testcasename;
	String username;
	Date execdate;
	String result;
	
	
	public TestCaseVO() {
		super();
	}



	public TestCaseVO(String testcasename, String username, Date execdate,
			String result) {
		super();
		this.testcasename = testcasename;
		this.username = username;
		this.execdate = execdate;
		this.result = result;
	}



	/**
	 * @return the testcasename
	 */
	public String getTestcasename() {
		return testcasename;
	}



	/**
	 * @param testcasename the testcasename to set
	 */
	public void setTestcasename(String testcasename) {
		this.testcasename = testcasename;
	}



	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}



	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}



	/**
	 * @return the execdate
	 */
	public Date getExecdate() {
		return execdate;
	}



	/**
	 * @param execdate the execdate to set
	 */
	public void setExecdate(Date execdate) {
		this.execdate = execdate;
	}



	/**
	 * @return the result
	 */
	public String getResult() {
		return result;
	}



	/**
	 * @param result the result to set
	 */
	public void setResult(String result) {
		this.result = result;
	}
	
	
	

}
