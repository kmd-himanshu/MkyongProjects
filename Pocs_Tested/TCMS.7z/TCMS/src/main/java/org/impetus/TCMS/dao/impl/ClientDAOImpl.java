/**
 * 
 */
package org.impetus.TCMS.dao.impl;

import org.impetus.TCMS.common.db.GenericDAOImpl;
import org.impetus.TCMS.dao.ClientDAO;


/**
 * @author kratika.gupta
 *
 */
public class ClientDAOImpl extends GenericDAOImpl implements ClientDAO {

	

}
