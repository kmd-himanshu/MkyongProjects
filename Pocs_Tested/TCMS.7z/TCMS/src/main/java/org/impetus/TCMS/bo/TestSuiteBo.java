/**
 * 
 */
package org.impetus.TCMS.bo;

import java.util.List;

import org.impetus.TCMS.model.Producttestsuite;
import org.impetus.TCMS.vo.TestSuiteVO;

/**
 * @author kratika.gupta
 *
 */
public interface TestSuiteBo {

	/*
	 * 
	 */
	//public String addNew(Producttestsuite prodtestsuite) throws Exception;
	
	/*
	 * 
	 */
	public List<TestSuiteVO> gettSuiteList(Integer clientId,Integer productId) throws Exception;
	
	/*
	 * 
	 */
	public Producttestsuite getTestSuiteFromId(Integer Id) throws Exception;
	
}
