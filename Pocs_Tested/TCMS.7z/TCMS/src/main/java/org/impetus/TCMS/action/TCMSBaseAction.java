/*
 * 
 */

package org.impetus.TCMS.action;

import com.opensymphony.xwork2.ActionSupport;

/**
 * Base Action class for the Application.
 */
public class TCMSBaseAction extends ActionSupport {

}
