/**
 * 
 */
package org.impetus.TCMS.dao;

import org.impetus.TCMS.common.db.GenericDAO;
import org.impetus.TCMS.model.Producttestcases;
import org.impetus.TCMS.model.Userdetails;

/**
 * @author kratika.gupta
 *
 */
public interface UserDAO extends GenericDAO {
	
	Userdetails findUserbyName(String username,String password) throws Exception;

	Userdetails getUserfromId(Integer Id) throws Exception;
}
