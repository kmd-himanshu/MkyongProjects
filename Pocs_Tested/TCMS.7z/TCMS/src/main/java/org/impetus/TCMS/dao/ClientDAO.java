/*
 * 
 */
package org.impetus.TCMS.dao;

public interface ClientDAO {

}
